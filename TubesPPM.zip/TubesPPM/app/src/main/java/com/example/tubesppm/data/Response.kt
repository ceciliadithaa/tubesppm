package com.example.tubesppm.data

data class Response(
    val error: Boolean,
    val message: String?
)
